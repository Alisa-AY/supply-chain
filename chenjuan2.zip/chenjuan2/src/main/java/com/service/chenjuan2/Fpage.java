package com.service.chenjuan2;

import java.sql.ResultSet;

public class Fpage {
    int pageNow = 0;//当前页
    int pageSize = 4;//页面大小
    int rowCount = 0;//共多少行
    int pageCount = 0;//共多少页
    int start = 0;

    public void setFpage(String sql, Object[] param){
        start = pageNow * pageSize;
        MysqlConn db = new MysqlConn();
        ResultSet rs = null;

        try{
            rs = db.doQuery(sql, param);
            if(rs.next()){
                rowCount = rs.getInt(1);
            }
            if(rowCount%pageSize==0)
                pageCount = rowCount / pageSize;
            else
                pageCount = rowCount / pageSize + 1;
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public int getPageNow() {
        return pageNow;
    }

    public void setPageNow(int pageNow) {
        this.pageNow = pageNow;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }
}
