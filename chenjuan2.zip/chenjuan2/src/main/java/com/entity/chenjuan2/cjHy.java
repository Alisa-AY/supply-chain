package com.entity.chenjuan2;

public class cjHy {
    private int cjid;
    private String cjname;
    private String cjphone;
    private double cjqb;
    private int cjjf;
    private String cjaddr;
    private String cjjb;
    private String cjdtime;

    public int getCjid() {
        return cjid;
    }

    public void setCjid(int cjid) {
        this.cjid = cjid;
    }

    public String getCjname() {
        return cjname;
    }

    public void setCjname(String cjname) {
        this.cjname = cjname;
    }

    public String getCjphone() {
        return cjphone;
    }

    public void setCjphone(String cjphone) {
        this.cjphone = cjphone;
    }

    public double getCjqb() {
        return cjqb;
    }

    public void setCjqb(double cjqb) {
        this.cjqb = cjqb;
    }

    public int getCjjf() {
        return cjjf;
    }

    public void setCjjf(int cjjf) {
        this.cjjf = cjjf;
    }

    public String getCjaddr() {
        return cjaddr;
    }

    public void setCjaddr(String cjaddr) {
        this.cjaddr = cjaddr;
    }

    public String getCjjb() {
        return cjjb;
    }

    public void setCjjb(String cjjb) {
        this.cjjb = cjjb;
    }

    public String getCjdtime() {
        return cjdtime;
    }

    public void setCjdtime(String cjdtime) {
        this.cjdtime = cjdtime;
    }
}
