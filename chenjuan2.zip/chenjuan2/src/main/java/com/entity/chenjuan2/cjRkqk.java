package com.entity.chenjuan2;

public class cjRkqk {
    private String cjid;
    private int cjgid;
    private String cjgname;
    private int cjsl;
    private double cjjprice;
    private double cjmprice;
    private String cjdtime;

    public String getCjid() {
        return cjid;
    }

    public void setCjid(String cjid) {
        this.cjid = cjid;
    }

    public int getCjgid() {
        return cjgid;
    }

    public void setCjgid(int cjgid) {
        this.cjgid = cjgid;
    }

    public String getCjgname() {
        return cjgname;
    }

    public void setCjgname(String cjgname) {
        this.cjgname = cjgname;
    }

    public int getCjsl() {
        return cjsl;
    }

    public void setCjsl(int cjsl) {
        this.cjsl = cjsl;
    }

    public double getCjjprice() {
        return cjjprice;
    }

    public void setCjjprice(double cjjprice) {
        this.cjjprice = cjjprice;
    }

    public double getCjmprice() {
        return cjmprice;
    }

    public void setCjmprice(double cjmprice) {
        this.cjmprice = cjmprice;
    }

    public String getCjdtime() {
        return cjdtime;
    }

    public void setCjdtime(String cjdtime) {
        this.cjdtime = cjdtime;
    }
}
