package com.entity.chenjuan2;

public class cjAdmin {
    private int cjid;
    private String cjuname;
    private String cjpassword;
    private String cjphone;

    public int getCjid() {
        return cjid;
    }

    public void setCjid(int cjid) {
        this.cjid = cjid;
    }

    public String getCjuname() {
        return cjuname;
    }

    public void setCjuname(String cjuname) {
        this.cjuname = cjuname;
    }

    public String getCjpassword() {
        return cjpassword;
    }

    public void setCjpassword(String cjpassword) {
        this.cjpassword = cjpassword;
    }

    public String getCjphone() {
        return cjphone;
    }

    public void setCjphone(String cjphone) {
        this.cjphone = cjphone;
    }
}
