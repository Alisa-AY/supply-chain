package com.entity.chenjuan2;

public class cjGoods {
    private int cjid;
    private String cjname;
    private String cjtxm;
    private String cjdw;
    private double cjjprice;
    private double cjmprice;
    private double cjzk1;
    private double cjzk2;
    private double cjzk3;
    private int cjkc;
    private String cjbz;
    private String cjdtime;

    public int getCjid() {
        return cjid;
    }

    public void setCjid(int cjid) {
        this.cjid = cjid;
    }

    public String getCjname() {
        return cjname;
    }

    public void setCjname(String cjname) {
        this.cjname = cjname;
    }

    public String getCjtxm() {
        return cjtxm;
    }

    public void setCjtxm(String cjtxm) {
        this.cjtxm = cjtxm;
    }

    public String getCjdw() {
        return cjdw;
    }

    public void setCjdw(String cjdw) {
        this.cjdw = cjdw;
    }

    public double getCjjprice() {
        return cjjprice;
    }

    public void setCjjprice(double cjjprice) {
        this.cjjprice = cjjprice;
    }

    public double getCjmprice() {
        return cjmprice;
    }

    public void setCjmprice(double cjmprice) {
        this.cjmprice = cjmprice;
    }

    public double getCjzk1() {
        return cjzk1;
    }

    public void setCjzk1(double cjzk1) {
        this.cjzk1 = cjzk1;
    }

    public double getCjzk2() {
        return cjzk2;
    }

    public void setCjzk2(double cjzk2) {
        this.cjzk2 = cjzk2;
    }

    public double getCjzk3() {
        return cjzk3;
    }

    public void setCjzk3(double cjzk3) {
        this.cjzk3 = cjzk3;
    }

    public int getCjkc() {
        return cjkc;
    }

    public void setCjkc(int cjkc) {
        this.cjkc = cjkc;
    }

    public String getCjbz() {
        return cjbz;
    }

    public void setCjbz(String cjbz) {
        this.cjbz = cjbz;
    }

    public String getCjdtime() {
        return cjdtime;
    }

    public void setCjdtime(String cjdtime) {
        this.cjdtime = cjdtime;
    }
}
