package com.dao.chenjuan2;

import com.entity.chenjuan2.cjGoodsls;
import com.service.chenjuan2.MysqlConn;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class cjGoodslsDAO {
    MysqlConn db = new MysqlConn();
    ResultSet rs = null;
    int res = 0;

    //查询会员信息
    public List<cjGoodsls> cjQuerySomeGoodsls(String sql, Object[] param){
        List<cjGoodsls> somegoods = new ArrayList<cjGoodsls>();
        try{
            rs = db.doQuery(sql, param);
            while(rs.next()){
                cjGoodsls cjgoods = new cjGoodsls();
                cjgoods.setCjid(rs.getInt("cjid"));
                cjgoods.setCjname(rs.getString("cjname"));
                cjgoods.setCjdw(rs.getString("cjdw"));
                cjgoods.setCjtxm(rs.getString("cjtxm"));
                cjgoods.setCjjprice(rs.getDouble("cjjprice"));
                cjgoods.setCjmprice(rs.getDouble("cjmprice"));
                cjgoods.setCjzk1(rs.getDouble("cjzk1"));
                cjgoods.setCjzk2(rs.getDouble("cjzk2"));
                cjgoods.setCjzk3(rs.getDouble("cjzk3"));
                cjgoods.setCjsl(rs.getInt("cjsl"));
                cjgoods.setCjrole(rs.getInt("cjrole"));
                somegoods.add(cjgoods);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return somegoods;
    }
    public int UpdateGoodsllsSl(int id, int role, int sl){
        res = db.doUpdate("update cjgoodsls set cjsl=? where cjid=? and cjrole=?", new Object[]{sl, id, role});
        db.close();
        return res;
    }
    public int cjDeleteGoodsls(int id, int role){
        res = db.doUpdate("delete from cjgoodsls where cjid=? and cjrole=?", new Object[]{id, role});
        db.close();
        return res;
    }
    public int cjDeleteGoodslsAll(int role){
        res = db.doUpdate("delete from cjgoodsls where cjrole=?", new Object[]{role});
        db.close();
        return res;
    }
}
