package com.dao.chenjuan2;

import com.entity.chenjuan2.cjHy;
import com.service.chenjuan2.MysqlConn;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class cjHyDAO {
    MysqlConn db = new MysqlConn();
    ResultSet rs = null;
    int res = 0;

    //查询会员信息
    public List<cjHy> cjQuerySomeHy(String sql, Object[] param){
        List<cjHy> somehy = new ArrayList<cjHy>();
        try{
            rs = db.doQuery(sql, param);
            while(rs.next()){
                cjHy cjhy = new cjHy();
                cjhy.setCjid(rs.getInt("cjid"));
                cjhy.setCjname(rs.getString("cjname"));
                cjhy.setCjphone(rs.getString("cjphone"));
                cjhy.setCjqb(rs.getDouble("cjqb"));
                cjhy.setCjjf(rs.getInt("cjjf"));
                cjhy.setCjaddr(rs.getString("cjaddr"));
                cjhy.setCjjb(rs.getString("cjjb"));
                cjhy.setCjdtime(rs.getDate("cjdtime")+" "+rs.getTime("cjdtime"));
                somehy.add(cjhy);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return somehy;
    }

    //根据ID查询会员信息
    public cjHy cjQueryHyById(int id){
        cjHy cjhy = new cjHy();
        try{
            rs = db.doQuery("select *from cjhy where cjid=?", new Object[]{id});
            if(rs.next()){
                cjhy.setCjid(rs.getInt("cjid"));
                cjhy.setCjname(rs.getString("cjname"));
                cjhy.setCjphone(rs.getString("cjphone"));
                cjhy.setCjqb(rs.getDouble("cjqb"));
                cjhy.setCjjf(rs.getInt("cjjf"));
                cjhy.setCjaddr(rs.getString("cjaddr"));
                cjhy.setCjjb(rs.getString("cjjb"));
                cjhy.setCjdtime(rs.getDate("cjdtime")+" "+rs.getTime("cjdtime"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return cjhy;
    }

    //添加会员信息
    public int cjAddHy(cjHy hy){
        res = db.doUpdate("insert into cjhy(cjname, cjphone, cjaddr, cjjb, cjdtime) values(?,?,?,?,now())",
                new Object[]{hy.getCjname(), hy.getCjphone(), hy.getCjaddr(), hy.getCjjb()});
        db.close();
        return res;
    }

    //修改会员信息
    public int cjUpdateHy(cjHy hy){
        res = db.doUpdate("update cjhy set cjname=?, cjphone=?, cjqb=?, cjjf=?, cjaddr=?, cjjb=?, cjdtime=? where cjid=?", new Object[]{
                hy.getCjname(), hy.getCjphone(), hy.getCjqb(), hy.getCjjf(), hy.getCjaddr(), hy.getCjjb(), hy.getCjdtime(), hy.getCjid()});
        db.close();
        return res;
    }

    //删除会员信息
    public int cjDeleteHy(int id){
        res = db.doUpdate("delete from cjhy where cjid=?", new Object[]{id});
        db.close();
        return res;
    }
}
