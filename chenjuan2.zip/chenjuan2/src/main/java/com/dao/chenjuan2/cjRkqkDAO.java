package com.dao.chenjuan2;

import com.entity.chenjuan2.cjRkqk;
import com.service.chenjuan2.MysqlConn;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class cjRkqkDAO {
    MysqlConn db = new MysqlConn();
    ResultSet rs = null;
    int res = 0;

    //查询入库情况
    public List<cjRkqk> cjQuerySomeRkqk(String sql, Object[] param){
        List<cjRkqk> somegoods = new ArrayList<cjRkqk>();
        try{
            rs = db.doQuery(sql, param);
            while(rs.next()){
                cjRkqk cjgoods = new cjRkqk();
                cjgoods.setCjid(rs.getString("cjid"));
                cjgoods.setCjjprice(rs.getDouble("cjjprice"));
                cjgoods.setCjmprice(rs.getDouble("cjmprice"));
                cjgoods.setCjsl(rs.getInt("cjsl"));
                cjgoods.setCjdtime(rs.getString("cjdtime"));
                somegoods.add(cjgoods);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return somegoods;
    }
    //查询入库详情
    public List<cjRkqk> cjQuerySomeRkxq(String sql, Object[] param){
        List<cjRkqk> somegoods = new ArrayList<cjRkqk>();
        try{
            rs = db.doQuery(sql, param);
            while(rs.next()){
                cjRkqk cjgoods = new cjRkqk();
                cjgoods.setCjid(rs.getString("cjid"));
                cjgoods.setCjgid(rs.getInt("cjgid"));
                cjgoods.setCjgname(rs.getString("cjgname"));
                cjgoods.setCjjprice(rs.getDouble("cjjprice"));
                cjgoods.setCjmprice(rs.getDouble("cjmprice"));
                cjgoods.setCjsl(rs.getInt("cjsl"));
                cjgoods.setCjdtime(rs.getString("cjdtime"));
                somegoods.add(cjgoods);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        db.close();
        return somegoods;
    }
}
