package com.action.chenjuan2;

import com.dao.chenjuan2.cjGoodslsDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/cjUpdateGoodslsSl")
public class cjUpdateGoodslsSl extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String str = request.getParameter("str");
        String str1[] = str.split("/");
        int id = Integer.parseInt(str1[0]);
        int role = Integer.parseInt(str1[1]);
        int sl = Integer.parseInt(str1[2]);
        System.out.println("id="+id+",role="+role+",sl="+sl);
        cjGoodslsDAO cjGoodslsDAO = new cjGoodslsDAO();
        int res = cjGoodslsDAO.UpdateGoodsllsSl(id, role, sl);
        if (res > 0) {
            if(role==0) {
                response.sendRedirect("cjQuerySprk");
            }else{
                response.sendRedirect("cjQuerySpls?role="+role);
            }
        }else{
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('数量修改失败!');history.go(-1);</script>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}