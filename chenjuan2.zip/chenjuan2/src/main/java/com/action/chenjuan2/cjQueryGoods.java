package com.action.chenjuan2;

import com.dao.chenjuan2.cjGoodsDAO;
import com.dao.chenjuan2.cjHyDAO;
import com.entity.chenjuan2.cjGoods;
import com.entity.chenjuan2.cjHy;
import com.service.chenjuan2.Fpage;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/cjQueryGoods")
public class cjQueryGoods extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String tj = "";
        if(request.getParameter("tj") != null){
            tj = request.getParameter("tj");
        }
        cjGoodsDAO gdao = new cjGoodsDAO();
        Fpage fpage = new Fpage();
        if(request.getParameter("page") != null){
            fpage.setPageNow(Integer.parseInt(request.getParameter("page")));
        }
        fpage.setFpage("select count(*)from cjgoods where cjname like '%"+tj+"%' or cjid like '%"+tj+"%'", new Object[]{});
        List<cjGoods> somegoods = gdao.cjQuerySomeGoods("select *from cjgoods where cjname like '%"+tj+"%' or cjid like '%"+tj+"%' limit ?,?",
                new Object[]{fpage.getStart(), fpage.getPageSize()});
        request.getSession().setAttribute("somegoods", somegoods);
        request.getSession().setAttribute("tj", tj);
        request.getSession().setAttribute("fpage", fpage);
        request.getSession().setAttribute("pageUrl", "cjQueryGoods");
        response.sendRedirect("cjgoodslist.jsp");
    }
}