package com.action.chenjuan2;

import com.jspsmart.upload.File;
import com.jspsmart.upload.SmartUpload;
import com.service.chenjuan2.ExcelBook;
import com.service.chenjuan2.MysqlConn;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;

@WebServlet("/cjExcel")
public class cjExcel extends HttpServlet {
    private ServletConfig config;
    public final void init(ServletConfig config) throws ServletException {
        this.config = config;
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = "D:/会员信息.xls";
        MysqlConn db = new MysqlConn();
        ResultSet rs = null;
        ExcelBook book = new ExcelBook();
        rs = db.doQuery("select *from cjhy", new Object[]{});

        book.excelOut(path,rs, new Object[]{"会员ID","会员名称", "会员电话","会员钱包","会员积分","会员地址","会员级别","会员时间"});
        System.out.println("导出成功");
        SmartUpload myload = new SmartUpload();
        try{
            myload.initialize(config, request, response);
            myload.downloadFile(path);
        }catch (Exception e){
            e.printStackTrace();
        }
        java.io.File file = new java.io.File(path);
        if(file.exists()){
            file.delete();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String path = "D:/会员信息.xls";
        SmartUpload myload = new SmartUpload();
        try{
            myload.initialize(config, request, response);
            myload.upload();
            File file = myload.getFiles().getFile(0);
            file.saveAs(path);
            ExcelBook book = new ExcelBook();
            MysqlConn db = new MysqlConn();
            ArrayList<String[]> list = book.ExcelIn(path);

            for(int i = 0 ; i < list.size() ; i++)
            {
                for(int j = 0 ; j < list.get(i).length ; j++)
                {
                    System.out.print(list.get(i)[j]+" ");
                }
                db.doUpdate("insert into cjhy values(?,?,?,?,?,?,?,?)", list.get(i));
                System.out.println();
            }
            java.io.File file1 = new java.io.File(path);
            if(file1.exists()){
                file1.delete();
            }
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('导入成功!');location.href='cjQueryHyzl';</script>");
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}