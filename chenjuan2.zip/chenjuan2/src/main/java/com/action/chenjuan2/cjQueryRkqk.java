package com.action.chenjuan2;

import com.dao.chenjuan2.cjGoodsDAO;
import com.dao.chenjuan2.cjRkqkDAO;
import com.entity.chenjuan2.cjGoods;
import com.entity.chenjuan2.cjRkqk;
import com.service.chenjuan2.Fpage;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/cjQueryRkqk")
public class cjQueryRkqk extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Date date = new Date();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        String tj = f.format(date);
        if(request.getParameter("tj")!=null)
            tj = request.getParameter("tj");System.out.println(tj);
        cjRkqkDAO rdao = new cjRkqkDAO();
        Fpage fpage = new Fpage();
        if(request.getParameter("page") != null){
            fpage.setPageNow(Integer.parseInt(request.getParameter("page")));
        }
        fpage.setFpage("SELECT COUNT(DISTINCT cjid) FROM cjrkqk WHERE cjdtime LIKE '%"+tj+"%'", new Object[]{});
        List<cjRkqk> somerkqk = rdao.cjQuerySomeRkqk("SELECT cjid, SUM(cjsl*cjjprice) AS cjjprice, SUM(cjsl*cjmprice) AS cjmprice, SUM(cjsl) AS cjsl, cjdtime FROM cjrkqk WHERE cjdtime LIKE '%"
                        +tj+"%' GROUP BY cjid,cjdtime order by cjid desc limit ?,?",
                new Object[]{fpage.getStart(), fpage.getPageSize()});
        request.getSession().setAttribute("somerkqk", somerkqk);
        request.getSession().setAttribute("tj", tj);
        request.getSession().setAttribute("fpage", fpage);
        request.getSession().setAttribute("pageUrl", "cjQueryRkqk");
        response.sendRedirect("cjrkqk.jsp");
    }
}