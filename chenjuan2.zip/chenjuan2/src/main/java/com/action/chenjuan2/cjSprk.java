package com.action.chenjuan2;

import com.service.chenjuan2.MysqlConn;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet("/cjSprk")
public class cjSprk extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        MysqlConn db = new MysqlConn();
        ResultSet rs = null;
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String id = "CJXSXT"+sdf.format(date);
        String date1 = sdf1.format(date);
        try{
            rs = db.doQuery("select *from cjgoodsls where cjrole=?", new Object[]{0});
            while(rs.next()){
                db.doUpdate("update cjgoods set cjkc=cjkc+? where cjid=?", new Object[]{rs.getInt("cjsl"),rs.getInt("cjid")});
                db.doUpdate("insert into cjrkqk values(?,?,?,?,?,?,?)", new Object[]{id, rs.getInt("cjid"), rs.getString("cjname"),
                rs.getInt("cjsl"), rs.getDouble("cjjprice"), rs.getDouble("cjmprice"), date1});
            }
            db.doUpdate("delete from cjgoodsls where cjrole=?", new Object[]{0});
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('入库成功!');location.href='cjQuerySprk';</script>");
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String txm = request.getParameter("txm");
        MysqlConn db = new MysqlConn();
        ResultSet rs = null;
        ResultSet rs1 = null;
        try{
            rs = db.doQuery("select *from cjgoods where cjtxm=?", new Object[]{txm});
            if(rs.next()){
                rs1 = db.doQuery("select *from cjgoodsls where cjtxm=? and cjrole=?", new Object[]{txm, 0});
                if(rs1.next()){
                    db.doUpdate("update cjgoodsls set cjsl=cjsl+1 where cjtxm=? and cjrole=?", new Object[]{txm, 0});
                }else{
                    db.doUpdate("insert into cjgoodsls values(?,?,?,?,?,?,?,?,?,?,?)", new Object[]{rs.getInt("cjid"), rs.getString("cjname"),
                    rs.getString("cjtxm"), rs.getString("cjdw"), rs.getDouble("cjjprice"), rs.getDouble("cjmprice"),
                    rs.getDouble("cjzk1"), rs.getDouble("cjzk2"), rs.getDouble("cjzk3"), 1, 0});
                }
                response.sendRedirect("cjQuerySprk");
            }else{
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.println("<script>alert('没有该商品!');location.href='cjQuerySprk';</script>");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}