package com.action.chenjuan2;

import com.dao.chenjuan2.cjHyDAO;
import com.entity.chenjuan2.cjHy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/cjUpdateHy")
public class cjUpdateHy extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        cjHyDAO hdao = new cjHyDAO();
        cjHy hy = hdao.cjQueryHyById(id);
        request.getSession().setAttribute("hy", hy);
        response.sendRedirect("cjupdatehy.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String phone = request.getParameter("phone");
        String name = request.getParameter("name");
        String addr = request.getParameter("addr");
        String jb = request.getParameter("jb");
        double qb = Double.parseDouble(request.getParameter("qb"));
        cjHy hy = (cjHy)request.getSession().getAttribute("hy");
        hy.setCjphone(phone);
        hy.setCjname(name);
        hy.setCjaddr(addr);
        hy.setCjjb(jb);
        hy.setCjqb(qb);
        cjHyDAO hdao = new cjHyDAO();
        int res = hdao.cjUpdateHy(hy);
        if(res > 0) {
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('修改成功!');location.href='cjUpdateHy?id="+hy.getCjid()+"';</script>");
        }else{
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('修改失败');history.go(-1);</script>");
        }

    }
}