package com.action.chenjuan2;

import com.dao.chenjuan2.cjHyDAO;
import com.entity.chenjuan2.cjHy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/cjAddHy")
public class cjAddHy extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        String phone = request.getParameter("phone");
        String name = request.getParameter("name");
        String addr = request.getParameter("addr");
        String jb = request.getParameter("jb");
        cjHy hy = new cjHy();
        hy.setCjname(name);
        hy.setCjphone(phone);
        hy.setCjaddr(addr);
        hy.setCjjb(jb);
        cjHyDAO hdao = new cjHyDAO();
        int res = hdao.cjAddHy(hy);
        if(res > 0) {
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('添加成功!');location.href='cjaddhy.jsp';</script>");
        }else{
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('添加失败');history.go(-1);</script>");
        }
    }
}