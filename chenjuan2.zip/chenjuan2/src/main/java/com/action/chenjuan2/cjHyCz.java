package com.action.chenjuan2;

import com.dao.chenjuan2.cjHyDAO;
import com.entity.chenjuan2.cjHy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/cjHyCz")
public class cjHyCz extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        cjHyDAO hdao = new cjHyDAO();
        cjHy hy = hdao.cjQueryHyById(id);
        request.getSession().setAttribute("hy", hy);
        response.sendRedirect("cjhycz.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        double qb = Double.parseDouble(request.getParameter("qb"));
        cjHy hy = (cjHy)request.getSession().getAttribute("hy");
        hy.setCjqb(qb+hy.getCjqb());
        cjHyDAO hdao = new cjHyDAO();
        int res = hdao.cjUpdateHy(hy);
        if(res > 0) {
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('充值成功!');location.href='cjHyCz?id="+hy.getCjid()+"';</script>");
        }else{
            response.setContentType("text/html;charset=utf-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('充值失败');history.go(-1);</script>");
        }
    }
}