package com.action.chenjuan2;

import com.dao.chenjuan2.cjGoodslsDAO;
import com.entity.chenjuan2.cjGoodsls;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/cjQuerySprk")
public class cjQuerySprk extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        cjGoodslsDAO gdao = new cjGoodslsDAO();
        List<cjGoodsls> somegoods = gdao.cjQuerySomeGoodsls("select *from cjgoodsls where cjrole=?", new Object[]{0});
        request.getSession().setAttribute("somegoods", somegoods);
        response.sendRedirect("cjsprk.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}