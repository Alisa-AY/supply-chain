package com.action.chenjuan2;

import com.entity.chenjuan2.cjAdmin;
import com.service.chenjuan2.MysqlConn;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

@WebServlet("/cjLogin")
public class cjLogin extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String uname = request.getParameter("uname");
        String pw = request.getParameter("pw");
        System.out.println(uname+pw);
        MysqlConn db = new MysqlConn();
        ResultSet rs = null;
        cjAdmin admin = new cjAdmin();
        try{
            rs = db.doQuery("select *from cjadmin where cjuname=? and cjpassword=?", new Object[]{uname, pw});
            if(rs.next()){
                admin.setCjid(rs.getInt("cjid"));
                admin.setCjuname(rs.getString("cjuname"));
                admin.setCjpassword(rs.getString("cjpassword"));
                admin.setCjphone(rs.getString("cjphone"));
                request.getSession().setAttribute("admin", admin);
                response.sendRedirect("cjmain.jsp");
            }else{
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.println("<script>alert('登录失败');history.go(-1);</script>");
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}