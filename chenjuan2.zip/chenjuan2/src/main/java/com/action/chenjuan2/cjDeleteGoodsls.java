package com.action.chenjuan2;

import com.dao.chenjuan2.cjGoodslsDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/cjDeleteGoodsls")
public class cjDeleteGoodsls extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int type = Integer.parseInt(request.getParameter("type"));
        int role = Integer.parseInt(request.getParameter("role"));
        cjGoodslsDAO gdao = new cjGoodslsDAO();
        if(type == 0){
            int id = Integer.parseInt(request.getParameter("id"));
            int res = gdao.cjDeleteGoodsls(id, role);
            if(res>0){
                if(role==0) {
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script>alert('删除成功!');location.href='cjQuerySprk';</script>");
                }else{
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script>alert('删除成功!');location.href='cjQuerySpls?role='"+role+";</script>");
                }
            }else{
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.println("<script>alert('删除失败!');history.go(-1);</script>");
            }
        }else{
            int res = gdao.cjDeleteGoodslsAll(role);
            if(res>0){
                if(role==0) {
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script>alert('清空成功!');location.href='cjQuerySprk';</script>");
                }else{
                    response.setContentType("text/html;charset=utf-8");
                    PrintWriter out = response.getWriter();
                    out.println("<script>alert('清空成功!');location.href='cjQuerySpls?role='"+role+";</script>");
                }
            }else{
                response.setContentType("text/html;charset=utf-8");
                PrintWriter out = response.getWriter();
                out.println("<script>alert('清空失败!');history.go(-1);</script>");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}